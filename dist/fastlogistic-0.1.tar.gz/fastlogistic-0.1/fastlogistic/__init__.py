from .logistic_cpu import LogisticRegression
from .logistic_gpu import LogisticRegressionGPU
